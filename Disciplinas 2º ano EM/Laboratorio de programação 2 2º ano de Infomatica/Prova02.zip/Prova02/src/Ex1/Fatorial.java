package Ex1;
import java.util.Scanner;
public class Fatorial {
    public static void main(String[] args){
        System.out.println(" ");
        Scanner entrada = new Scanner(System.in);
        double n, f = 1;
        double a = 1;
        do{
            System.out.print("Digite um número para ser fatorado: ");
            n = entrada.nextDouble();
            for(int i = 1;i <= n; i++){
                f = f * i;
            }
            System.out.println(" ");
            System.out.println("O ! do " + n + " é igual a " + f + ".");
            System.out.println(" ");
        }while(a >= 1);
    }
}