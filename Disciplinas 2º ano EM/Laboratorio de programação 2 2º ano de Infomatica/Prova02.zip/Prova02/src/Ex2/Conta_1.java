package Ex2;

public class Conta_1 {
    public void setcodConta(String codConta) {
    }

    public void setnomeCliente(String nomeCliente) {
    }

    public void setSaldo(double saldo) {
    }

    public class Conta {
        private String codConta;
        private String nomeCliente;
        private double saldo;

        public Conta(String numero, String nome, double saldo) {
            this.codConta = codConta;
            this.nomeCliente = nome;
            this.saldo = saldo;
        }

        public String getNumero() {
            return codConta;
        }

        public String getNome() {
            return nomeCliente;
        }

        public double getSaldo() {
            return saldo;
        }

        public void setNumero(String numero) {
            this.codConta = numero;
        }

        public void setNome(String nome) {
            this.nomeCliente = nome;
        }

        public void setSaldo(double saldo) {
            this.saldo = saldo;
        }

        public Conta() {
        }
    }
}



