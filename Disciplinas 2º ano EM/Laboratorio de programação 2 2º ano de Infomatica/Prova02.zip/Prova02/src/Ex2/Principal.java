package Ex2;

import java.util.Scanner;

public class Principal{

    public static void main(String[] args){

        Scanner entrada = new Scanner(System.in);
        Conta_1 a = new Conta_1();

        int i = 0;

        do {
            System.out.println("1 - Adicionar conta");
            System.out.println("2 - buscar conta");
            System.out.println("3 - remover conta");
            System.out.println("4 - editar conta");
            System.out.println("0 - Sair");
            System.out.println(" ");
            System.out.println("Digite uma opção: ");
            i = entrada.nextInt();


            switch (i) {
                case 1 : {
                    System.out.println("Digite o número da Conta: ");
                    String codConta = entrada.next();
                    a.setcodConta(codConta);
                    System.out.print("Digite o nome do cliente: ");
                    String nomeCliente = entrada.next();
                    a.setnomeCliente(nomeCliente);
                    System.out.print("Digite o valor saldo: ");
                    double saldo = entrada.nextDouble();
                    a.setSaldo(saldo);
                    System.out.println(" ");
                }break;

                case 2 : {
                    System.out.println("Digite o código da conta que você deseja buscar: ");
                    String numero = entrada.next();
                    System.out.printf("Número do Cliente:
                }break;

                case 3 : {
                    System.out.println("Digite o código da conta que você deseja deletar: ");
                    String numero = entrada.next();
                    System.out.println(" ");
                }break;

                case 4 :
                    System.out.println("Número da Conta: ");
                    String codConta = entrada.next();
                    a.setcodConta(codConta);
                    System.out.print("Nome do Cliente: ");
                    String nomeCliente = entrada.next();
                    a.setnomeCliente(nomeCliente);
                    System.out.print("Informe o valor saldo: ");
                    double saldo = entrada.nextDouble();
                    a.setSaldo(saldo);
                    System.out.println(" ");
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + i);
            }
        }
        while ( != 0);
    }
}