package Calculadora;

import javax.swing.Action;
import javax.swing.plaf.LabelUI;
import javax.swing.plaf.basic.BasicBorders.ButtonBorder;

import a;

public class TelaCalculadoraController extends a {

    public static void main(String[] args) throws Exception {
        launch(args);
    }

    private static void launch(String[] args) {
    }

    private LabelUI Tela;

    private ButtonBorder Subtrair;

    private ButtonBorder Zero;

    private ButtonBorder Quatro;

    private ButtonBorder Sete;

    private ButtonBorder Apagar;

    private ButtonBorder Somar;

    private ButtonBorder Tres;

    private ButtonBorder Oito;

    private ButtonBorder Dividir;

    private ButtonBorder Multiplicar;

    private ButtonBorder Nove;

    private ButtonBorder Cinco;

    private ButtonBorder Dois;

    private ButtonBorder Igual;

    private ButtonBorder Um;

    private ButtonBorder Seis;

    void ImprimeResultado(Action event) {

    }

    void DivideNumero(Action event) {

    }

    void MultiplicaNumero(Action event) {

    }

    void SubtraiNumero(Action event) {

    }

    void SomaNumero(Action event) {

    }

    void Oito(Action event) {

    }

    void Sete(Action event) {

    }

    void Nove(Action event) {

    }

    void Quatro(Action event) {

    }

    void Cinco(Action event) {

    }

    void Seis(Action event) {

    }

    void Dois(Action event) {

    }

    void ApagaTela(Action event) {

    }

    void CalculaResultado(Action event) {

    }

    void Um(Action event) {

    void Tres(Action event) {

    }

    void Zero(Action event) {

    }

}
